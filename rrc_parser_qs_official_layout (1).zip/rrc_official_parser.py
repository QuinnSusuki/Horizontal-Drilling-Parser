import pandas as pd
from tkinter import Tk, filedialog

def parse_line(line):
    return {
        "Permit_Number": line[0:7].strip(),
        "Permit_Sequence": line[7:9].strip(),
        "District": line[9:11].strip(),
        "County_Name": line[11:24].strip(),
        "API_County_Code": line[24:27].strip(),
        "API_Unique_Number": line[27:32].strip(),
        "Operator_Number": line[32:38].strip(),
        "Operator_Name": line[38:70].strip(),
        "Lease_Name": line[70:102].strip(),
        "Permit_Issued_Date": line[102:110].strip(),
        "Total_Depth": line[110:115].strip(),
        "Section": line[115:123].strip(),
        "Block": line[123:133].strip(),
        "Abstract": line[133:139].strip(),
        "Survey": line[139:194].strip(),
        "Well_Number": line[194:200].strip(),
        "Field_Name": line[200:232].strip(),
        "Validated_Field_Name": line[232:264].strip(),
        "Validated_Well_Date": line[264:272].strip(),
        "Validated_Operator_Name": line[272:304].strip(),
        "Oil_or_Gas": line[304:305].strip(),
        "Validated_Lease_Number": line[305:311].strip(),
        "Validated_Lease_Name": line[311:343].strip(),
        "Validated_Well_Number": line[343:349].strip(),
        "Off_Schedule_Flag": line[349:350].strip(),
        "Total_Permitted_Fields": line[350:352].strip(),
        "Total_Validated_Fields": line[352:354].strip()
    }

def parse_to_csv(file_path):
    print(f"Parsing: {file_path}")
    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        lines = f.readlines()
    valid_lines = [line for line in lines if len(line.strip()) >= 354]
    parsed_data = [parse_line(line) for line in valid_lines]
    df = pd.DataFrame(parsed_data)

    output_path = "Horizontal Drilling Permits - Full Parsed Format.csv"
    df.to_csv(output_path, index=False)
    print(f"✅ CSV saved as: {output_path}")

def main():
    print("Select the RRC .txt file (daf318)...")
    Tk().withdraw()
    file_path = filedialog.askopenfilename(title="Select RRC permit file")
    if not file_path:
        print("❌ No file selected.")
        return
    parse_to_csv(file_path)

if __name__ == "__main__":
    main()
