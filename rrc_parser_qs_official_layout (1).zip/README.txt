============================
QS RRC Horizontal Drilling Parser
============================

This tool uses the official layout from the Texas RRC Horizontal Drilling Permits spec.

How to use:

1. Install Python from https://www.python.org/downloads/
   - CHECK [✓] Add Python to PATH
   - Or click Customize Installation → Next → 
     CHECK [✓] "Add Python to environment variables"

2. Open Command Prompt and install pandas:
   pip install pandas

3. Double-click the "run_qs_official_parser.bat" file.

4. Select the RRC .txt file (like daf318)

5. It will create a file:
   "Horizontal Drilling Permits - Full Parsed Format.csv"

✅ Includes all documented fields in official order.
